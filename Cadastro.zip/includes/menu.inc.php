<nav class="blue-grey">
    <div class="nav-wrapper container">
        <div class="brand-logo light">Cadastro de Clientes</div>
        <ul class="right">
            <li><a href="index.php"><i class="material-icons left">account_circle</i> Cadastro </a></li>
            <li><a href="consultas.php"><i class="material-icons left">search</i> Consultas </a></li>
        </ul>
    </div>
</nav>