<html>

<head>
    <meta charset="UTF-8">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link rel="stylesheet" href="libs/materialize/css/materialize.min.css" />
    <link rel="shorcut icon" href="imagens/Favicon.png" type="image/x-png" />
    <title>Cadastro</title>
</head>

<body>