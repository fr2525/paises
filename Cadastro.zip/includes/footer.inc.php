<!-- Arquivos Jquery e Materialize -->
<script type="text/javascript" src="libs/materialize/js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="libs/materialize/js/materialize.min.js"></script>

<!-- Inicialização Jquery -->
<script type="text/javascript">
    $(document).ready(function() {

    });
</script>
</body>

</html>