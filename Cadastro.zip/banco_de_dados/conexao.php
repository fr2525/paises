<?php

include_once 'conexao.class.php';

$utf8 = header("Content-Type: text/html; charset=utf-8");

$conexaoOk = false;

$conectando = new conexao();

$conexaoOk = $conectando->connect();

If (!$conexaoOk)
    die("Conexão ao banco falhou, entre em contato com a T.I.");

while (!$conexaoOk) :

    @$link = new mysqli('localhost','root','','db_financeiro');

    /* check connection */
    if ($link->connect_errno == 1049) {
        // Conexao falhou banco não existe: Criando o banco

        exit();
    }
endwhile

$link->set_charset('utf8');
echo "Success: A proper connection to MySQL was made! The my_db database is great." . PHP_EOL;
echo "Host information: " . mysqli_get_host_info($link) . PHP_EOL;

//mysqli_close($link);